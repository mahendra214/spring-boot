package come.spring.data.jpa.service;

import org.springframework.stereotype.Service;

@Service
public interface EmailService {
	
	public void sendMail(String toAddress,String fromAddress,String  content);

}
