package come.spring.data.jpa.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import come.spring.data.jpa.model.Account;

@Repository
public interface AccountRepository {
	
	
	public Account findAccountByNumber(Long accountNUmber) throws SQLException;
	public List<Account> findAllAccounts() throws SQLException;;
	public void save(Account account) throws SQLException;;
	public void update(Account account)throws SQLException;;
	public void delete(Account account) throws SQLException;;
}
