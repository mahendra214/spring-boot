package come.spring.data.jpa.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import come.spring.data.jpa.model.TransactionDetail;



@Repository
public interface TransactionRepository {

	public Long addTransaction(TransactionDetail transactionDetail) throws SQLException;
	public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber) throws SQLException;
}
