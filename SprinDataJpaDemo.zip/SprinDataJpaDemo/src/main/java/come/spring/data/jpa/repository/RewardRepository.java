package come.spring.data.jpa.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import come.spring.data.jpa.model.Reward;



@Repository
public interface RewardRepository {
	
	public void addReward(Reward reward) throws SQLException;
	public int getTotalRewardAmount(Long accountNumber) throws SQLException;
	public List<Reward> getAllRewardsForAccount(Long accountNUmber)throws SQLException;
	
	

}
