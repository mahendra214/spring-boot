package come.spring.data.jpa;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import come.spring.data.jpa.service.BankService;

@RunWith(SpringRunner.class)
@SpringBootTest
class SprinDataJpaDemoApplicationTests {

	@Autowired
	private BankService bankService;
	@Test
	void contextLoads() throws SQLException {
		Long transactionId=bankService.transfer(new Long(1), new Long(2), 5000);
		assertNotNull(transactionId);
	}

}
