package com.example.springdatajpa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.springdatajpa.entity.Product;

@Repository
public interface ProductDAO extends CrudRepository<Product, Integer>{
	
	
//	@Query("select p from Product p where p.price>1500")
//	List<Product> getProducts();
	

	//indexed parameter - one by one to multiple parameter incase
	@Query("select p from Product p where p.price> ?1")
	List<Product> getProductsIndexedParameter(double price);

	

	//named parameter
		@Query("select p from Product p where p.price > :price")
		List<Product> getProductsNamedParameter(@Param("price")double price);
//	
//	
//	Product findByName(String name);
//	
	List<Product> findAllByPriceGreaterThan(double price);
	
 	List<Product> findAllByPrice(double price);
//	
	List<Product> findAllByNameContainingAndPriceGreaterThan(String name, double price);
	
		
}
