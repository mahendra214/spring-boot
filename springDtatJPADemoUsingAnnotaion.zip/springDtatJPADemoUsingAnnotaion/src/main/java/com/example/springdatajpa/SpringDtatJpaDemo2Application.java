package com.example.springdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDtatJpaDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDtatJpaDemo2Application.class, args);
	}

}
