package com.example.springdatajpa;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.springdatajpa.dao.ProductDAO;
import com.example.springdatajpa.entity.Product;


@SpringBootTest
class SpringDtatJpaDemo2ApplicationTests {

	@Autowired
	ProductDAO productDAO;

	@Test
	void createProduct() throws Exception {
		Product product = new Product(1, "Mahndra", "description", 1000.00);
		productDAO.save(product);
		
		Optional<Product> optional = productDAO.findById(2);
		if(!optional.isPresent()) {
			System.out.println("Not present");
		}
		else {
			Product product2 = optional.get();
			System.out.println(product2);
		}
		
				
		
		productDAO.save(new Product(2, "mahendra2", "description2", 1002.00));
		productDAO.save(new Product(3, "Sudipta3", "description3", 1500.00));
		productDAO.save(new Product(4, "Sudipta4", "description4", 2000.00));
		productDAO.save(new Product(5, "Sudipta5", "description5", 2500.00));
		productDAO.save(new Product(6, "Sudipta6", "description6", 3000.00));
		productDAO.save(new Product(7, "Sudipta7", "description7", 3000.00));
		
		System.out.println(productDAO.findAllByPrice(3000.00));
		System.out.println(productDAO.findAllByPriceGreaterThan(1500.00));
		
//		
//		System.out.println("-------------prodiucts------------------");
//		System.out.println(productDAO.getProducts());
//		System.out.println("-------------------------------");
//		System.out.println(productDAO.findByName("Sudipta2"));
//		System.out.println("-------------------------------");
//		System.out.println(productDAO.findAllByPriceGreaterThan(2000));
		System.out.println("-------------------------------");
		System.out.println(productDAO.findAllByNameContainingAndPriceGreaterThan("Sudipta", 100));
		
		System.out.println("-------------prodiucts 999------------------");
		System.out.println(productDAO.getProductsIndexedParameter(999.00));
		System.out.println("-------------prodiucts 2000------------------");
		System.out.println(productDAO.getProductsNamedParameter(2000.00));
		
	}
}
